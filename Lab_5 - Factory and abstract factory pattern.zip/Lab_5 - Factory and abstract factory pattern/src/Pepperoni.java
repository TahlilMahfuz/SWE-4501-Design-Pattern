public interface Pepperoni {
    String getPepperoni();
}
