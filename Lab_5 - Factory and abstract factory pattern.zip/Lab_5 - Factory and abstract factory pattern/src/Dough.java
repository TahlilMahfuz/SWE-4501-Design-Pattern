public interface Dough {
    String getDough();
}
