public interface Sauce {
    String getSauce();
}
