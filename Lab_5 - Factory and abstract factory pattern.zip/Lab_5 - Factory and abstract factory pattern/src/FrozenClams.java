public class FrozenClams implements Clams{
    @Override
    public String getClams() {
        return "Frozen Clams";
    }
}
