public class BlackOlives implements Veggies{

    @Override
    public String getVeggies() {
        return "Black Olives";
    }
}
