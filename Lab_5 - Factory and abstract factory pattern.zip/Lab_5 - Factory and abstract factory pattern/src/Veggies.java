public interface Veggies {
    String getVeggies();
}
