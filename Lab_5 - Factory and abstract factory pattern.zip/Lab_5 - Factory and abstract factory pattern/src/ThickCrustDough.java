public class ThickCrustDough implements Dough{
    @Override
    public String getDough() {
        return "Thick Crust Dough";
    }
}
