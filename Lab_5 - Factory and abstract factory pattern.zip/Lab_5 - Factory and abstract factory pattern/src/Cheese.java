public interface Cheese {
    String getCheese();
}
