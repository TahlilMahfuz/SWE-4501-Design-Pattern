class ReggianoCheese implements Cheese {
    public String getCheese() {
        return "Reggiano Cheese";
    }
}