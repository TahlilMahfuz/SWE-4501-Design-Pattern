public interface Clams {
    String getClams();
}
