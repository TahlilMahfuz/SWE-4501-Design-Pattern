class MarinaraSauce implements Sauce {
    public String getSauce() {
        return "Marinara Sauce";
    }
}