class RedPepper implements Veggies {

    @Override
    public String getVeggies() {
        return "Red Pepper";
    }
}