class FreshClams implements Clams {
    public String getClams() {
        return "Fresh Clams";
    }
}