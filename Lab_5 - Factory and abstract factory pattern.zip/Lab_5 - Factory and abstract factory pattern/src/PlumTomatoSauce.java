public class PlumTomatoSauce implements Sauce{
    @Override
    public String getSauce() {
        return "Plum Tomato Sauce";
    }
}
