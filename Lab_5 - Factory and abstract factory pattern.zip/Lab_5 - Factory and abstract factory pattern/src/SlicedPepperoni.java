class SlicedPepperoni implements Pepperoni {
    public String getPepperoni() {
        return "Sliced Pepperoni";
    }
}