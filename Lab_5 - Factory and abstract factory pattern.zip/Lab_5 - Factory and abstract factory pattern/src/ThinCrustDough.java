class ThinCrustDough implements Dough {
    public String getDough() {
        return "Thin Crust Dough";
    }
}



