public class MozzarellaCheese implements Cheese{
    @Override
    public String getCheese() {
        return "Mozzarella Cheese";
    }
}
